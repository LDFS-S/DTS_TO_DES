# Global constants
STRAIGHT_SPEED = 3600  # Straight speed in mm/s
CURVE_SPEED = 800  # Curve speed in mm/s
VEHICLE_LENGTH = 800  # Vehicle length in mm
DEFAULT_SAFE_DISTANCE = 400  # Default safe distance in mm


def calculate_max_speed(arrival_time_front_vehicle, current_simulation_time, safety_distance, control_point_length,
                        load_unload_time):
    """
    Calculate the maximum speed for the following vehicle to arrive at the next control point (CP)
    while maintaining a safe distance, considering the loading/unloading time of the front vehicle.

    :param arrival_time_front_vehicle: Expected arrival time at the next CP of the front vehicle.
    :param current_simulation_time: Current time in the simulation.
    :param safety_distance: Required safety distance to maintain from the front vehicle.
    :param control_point_length: Distance to the next control point.
    :param load_unload_time: Time spent by the front vehicle loading/unloading at the CP.
    :return: Maximum safe speed for the following vehicle.
    """
    # Available time window for the following vehicle to reach the next CP.
    time_window = arrival_time_front_vehicle - current_simulation_time
    if time_window <= 0:
        return 0
    effective_distance = control_point_length - safety_distance
    # Adjusting the time window by adding loading/unloading time.
    adjusted_time_window = time_window + load_unload_time
    # Calculating the max safe speed considering the effective distance and adjusted time window.
    max_safe_speed = effective_distance / adjusted_time_window if adjusted_time_window > 0 else 0
    return max_safe_speed


def generate_velocity(car_volume, path_length, is_curved, safety_distance, arrival_time_front_vehicle,
                      simulation_current_time, load_unload_duration, path_max_volume):
    """
    Generate the velocity of a vehicle based on the path's capacity and density, considering the front vehicle's behavior.

    :param path_max_volume: Capacity of the path (number of vehicles it can handle).
    :param car_volume: Number of cars in the path
    :param path_length: Length of the path.
    :param is_curved: Boolean indicating if the path is curved.
    :param safety_distance: Safe distance to maintain from a vehicle ahead.
    :param arrival_time_front_vehicle: Arrival time of the vehicle in front.
    :param simulation_current_time: Current simulation time.
    :param load_unload_duration: Time for loading/unloading at the CP.
    :return: Generated velocity for the vehicle on this path.
    """
    # Base speed is set based on whether the path is curved.
    maximum_speed = CURVE_SPEED if is_curved else STRAIGHT_SPEED
    # If there is a front vehicle, calculate the max possible speed with it considered.

    max_possible_speed = base_speed if arrival_time_front_vehicle == 0 else calculate_max_speed(
        arrival_time_front_vehicle, simulation_current_time, safety_distance, path_length, load_unload_duration)

    # Estimated density of vehicles on the path.
    maximum_density = path_max_volume / path_length
    current_density = car_volume / path_length
    velocity = maximum_speed * (1 - current_density / maximum_density)
    # Speed reduction factor based on estimated density.
    # Generated velocity is the minimum of base speed adjusted by density factor or max possible speed.
    generated_velocity = min(velocity, max_possible_speed)
    return generated_velocity


def calculate_arrival_time(path_length, calculated_velocity):
    """
    Calculate the time it will take for a vehicle to travel a certain distance given the velocity.

    :param path_length: The length of the path the vehicle will travel.
    :param calculated_velocity: The velocity of the vehicle.
    :return: The time it will take for the vehicle to travel the length of the path.
    """
    if calculated_velocity <= 0:
        return float('inf')  # 返回无穷大，表示在这个速度下车辆无法到达目的地
    return path_length / calculated_velocity


def run_simulation(car_volume, path_length, is_curved, arrival_time_front_vehicle,
                   simulation_current_time, load_unload_duration, path_max_volume):
    """
    Run the traffic simulation with the given parameters and return the results.

    :param car_volume: Number of cars on the path
    :param path_length: Length of the path
    :param is_curved: Is path curved
    :param arrival_time_front_vehicle: Arrival time of the front vehicle
    :param simulation_current_time: Current simulation time
    :param load_unload_duration: Load/unload duration at the CP
    :param path_max_volume: Maximum capacity of the path
    :return: Tuple containing the generated velocity and the estimated arrival time
    """
    generated_velocity = generate_velocity(
        car_volume, path_length, is_curved, DEFAULT_SAFE_DISTANCE, arrival_time_front_vehicle,
        simulation_current_time, load_unload_duration, path_max_volume
    )
    time_of_arrival = calculate_arrival_time(path_length, generated_velocity)
    return generated_velocity, time_of_arrival
