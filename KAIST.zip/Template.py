from generate_velocity import run_simulation

# 设置测试参数
test_car_volume = 5
test_path_length = 10000
test_is_curve = False
test_loading_unloading_time = 10
test_current_time = 1
test_front_vehicle_arrival = 5
test_path_capacity = 8

# 调用函数并获取结果
velocity, arrival_time = run_simulation(
    test_car_volume, test_path_length, test_is_curve,
    test_loading_unloading_time, test_current_time, test_front_vehicle_arrival, test_path_capacity
)

print(f"Generated velocity: {velocity} mm/s")
print(f"Estimated arrival time: {arrival_time} seconds")