import unittest
from generate_velocity import (
    calculate_max_speed, generate_velocity, calculate_arrival_time, run_simulation, TrafficSimulationError
)


class TestVelocityProfile(unittest.TestCase):
    # Tests for the calculate_max_speed function
    def test_calculate_max_speed_normal(self):
        # Test normal case with valid time and safety distance
        self.assertEqual(calculate_max_speed(15, 5, 400, 10000, 5), 640)

    def test_calculate_max_speed_invalid_time(self):
        # Test with invalid time values (front vehicle arrival time before current time)
        with self.assertRaises(TrafficSimulationError):
            calculate_max_speed(5, 10, 400, 10000, 5)

    def test_calculate_max_speed_negative_safety_distance(self):
        # Test with negative safety distance value
        with self.assertRaises(TrafficSimulationError):
            calculate_max_speed(15, 5, -400, 10000, 5)

    # Tests for the generate_velocity function
    def test_generate_velocity_invalid_car_volume(self):
        # Test with car volume exceeding the path's maximum capacity
        with self.assertRaises(TrafficSimulationError):
            generate_velocity(11, 10000, False, 400, 10, 1, 0, 10)

    def test_generate_velocity_invalid_path_length(self):
        # Test with zero or negative path length
        with self.assertRaises(TrafficSimulationError):
            generate_velocity(5, 0, False, 400, 10, 1, 0, 10)

    # Tests for the calculate_arrival_time function
    def test_calculate_arrival_time_zero_velocity(self):
        # Test with zero velocity (should return infinity)
        self.assertEqual(calculate_arrival_time(10000, 0, 1), float('inf'))

    def test_calculate_arrival_time_invalid_path_length(self):
        # Test with zero or negative path length
        with self.assertRaises(TrafficSimulationError):
            calculate_arrival_time(0, 360, 1)

    # Tests for the run_simulation function
    def test_run_simulation_invalid_input(self):
        # Test with negative number of cars
        with self.assertRaises(TrafficSimulationError):
            run_simulation(-1, 10000, False, 10, 1, 0, 10)

    # Boundary case tests for calculate_max_speed
    def test_calculate_max_speed_zero_load_unload_time(self):
        # Test case with zero load/unload time
        self.assertEqual(calculate_max_speed(15, 5, 400, 10000, 0), 960)

    # Boundary case tests for calculate_arrival_time
    def test_calculate_arrival_time_max_velocity(self):
        # Test case with maximum velocity
        self.assertEqual(calculate_arrival_time(10000, 3600, 1), 2.7777777777777777)

    # Additional tests for run_simulation can be added here
    # ...


if __name__ == '__main__':
    unittest.main()
