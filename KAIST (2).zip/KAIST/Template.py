from generate_velocity import run_simulation

# Set test parameters
test_car_volume = 5  # Number of cars on the path
test_path_length = 10000  # Length of the path in mm
test_is_curve = False  # Indicates if the path is curved
test_loading_unloading_time = 8  # Loading/unloading time at the control point
test_current_time = 2  # Current time in the simulation
test_front_vehicle_arrival = 8  # Arrival time of the front vehicle
test_path_capacity = 8  # Maximum capacity of the path

# Call the function and get the results
velocity, arrival_time = run_simulation(test_car_volume, test_path_length, test_is_curve, test_current_time,
                                        test_loading_unloading_time, test_path_capacity, test_front_vehicle_arrival)

print(f"Generated velocity: {velocity} mm/s")
print(f"Estimated arrival time: {arrival_time} seconds")

# Set test parameters without front vehicle arrival time
test_car_volume = 5
test_path_length = 10000
test_is_curve = False
test_loading_unloading_time = 8
test_current_time = 2
test_path_capacity = 8

# Call the function and get the results without specifying front vehicle arrival time
velocity, arrival_time = run_simulation(test_car_volume, test_path_length, test_is_curve, test_current_time,
                                        test_loading_unloading_time, test_path_capacity)

print(f"Generated velocity(free flow): {velocity} mm/s")
print(f"Estimated arrival time(free flow): {arrival_time} seconds")
